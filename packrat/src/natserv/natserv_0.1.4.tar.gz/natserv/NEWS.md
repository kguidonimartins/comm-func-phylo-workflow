natserv 0.1.4
=============

### MINOR IMPROVEMENTS

* `natserv` now requires `crul` `>= 0.2.0`, which fixed URL encoding
to make our work in `natserv` easier.


natserv 0.1.0
=============

### NEW FEATURES

* released to CRAN
