
library(testthat)
test_check("rncl")
