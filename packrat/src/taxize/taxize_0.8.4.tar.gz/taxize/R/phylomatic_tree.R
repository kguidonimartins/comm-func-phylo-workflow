#' Query Phylomatic for a phylogenetic tree.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname phylomatic_tree-defunct
#' @param ... Parameters, ignored
phylomatic_tree <- function(...) {
  .Defunct(msg = "This function is defunct - See ?`taxize-defunct`")
}
