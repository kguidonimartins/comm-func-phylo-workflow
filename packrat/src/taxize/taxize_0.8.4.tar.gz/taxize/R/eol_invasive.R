#' Search for presence of taxonomic names in EOL invasive species databases.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname eol_invasive-defunct
#' @keywords internal
eol_invasive <- function(...) {
  .Defunct("eol", "originr", msg = "This function is defunct. See originr::eol()")
}
