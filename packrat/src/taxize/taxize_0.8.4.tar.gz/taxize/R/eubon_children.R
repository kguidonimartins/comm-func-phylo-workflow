#' EUBON children
#'
#' @export
#' @param id (character) identifier for the taxon. (LSID, DOI, URI, or any
#' other identifier used by the checklist provider)
#' @param providers (character) A list of provider id strings concatenated by
#' comma characters. The default : "pesi,bgbm-cdm-server[col]" will be used if
#' this parameter is not set. A list of all available provider ids can be
#' obtained from the '/capabilities' service end point. Providers can be
#' nested, that is a parent provider can have sub providers. If the id of the
#' parent provider is supplied all subproviders will be queried. The query
#' can also be restriced to one or more subproviders by using the following
#' syntax: parent-id[sub-id-1,sub-id2,...]
#' @param timeout (numeric) The maximum of milliseconds to wait for responses
#' from any of the providers. If the timeout is exceeded the service will just
#' return the resonses that have been received so far. The default timeout is
#' 0 ms (wait for ever)
#' @param ... Curl options passed on to \code{\link[httr]{GET}}
#' @references \url{http://cybertaxonomy.eu/eu-bon/utis/1.2/doc.html}
#' @return a data.frame or an empty list if no results found
#' @family eubon-methods
#' @examples \dontrun{
#' x <- eubon_children(id = "urn:lsid:marinespecies.org:taxname:126141",
#'   providers = 'worms')
#' head(x)
#' }
eubon_children <- function(id, providers = NULL, timeout = 0, ...) {
  args <- tc(list(providers = paste0(providers, collapse = ","),
                  timeout = timeout))
  res <- httr::GET(file.path(eubon_base(), "classification", id, "children"),
                   query = args, ...)
  eubon_error(res)
  tmp <- jsonlite::fromJSON(con_utf8(res), TRUE, flatten = TRUE)
  tmp$query$response[[1]]
}
