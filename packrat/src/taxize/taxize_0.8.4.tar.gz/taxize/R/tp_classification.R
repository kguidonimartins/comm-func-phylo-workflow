#' Return all synonyms for a taxon name with a given id.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname tp_classification-defunct
#' @keywords internal
tp_classification <- function(...) {
  .Defunct(msg = "This function is defunct. See classification().")
}
