#' Search uBio by namebank ID.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @rdname ubio_id-defunct
#' @export
#' @param ... Parameters, ignored
ubio_id <- function(...) {
  .Defunct(msg = "the uBio API is down, for good as far as we know")
}
