context("iucn_getname")


# test_that("iucn_getname returns the correct value", {
#   skip_on_cran()

#   temp <- iucn_getname(name = "Cyanistes caeruleus", verbose = FALSE)

#   expect_equal(temp, "Parus caeruleus")

# 	expect_is(temp, "character")

#   expect_equal(length(temp), 1)
# })
