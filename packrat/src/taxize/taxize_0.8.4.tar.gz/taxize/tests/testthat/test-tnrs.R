# tests for itis fxn in taxize
context("tnrs")


# test_that("tnrs returns the correct value", {
#   skip_on_cran()
#
#   mynames <- c("Panthera tigris", "Eutamias minimus")
#   out <- tnrs(query = mynames, verbose = FALSE)
#
#   expect_that(ncol(out), equals(7))
#
#   expect_that(out, is_a("data.frame"))
# })
