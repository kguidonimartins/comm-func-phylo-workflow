library(testthat)
library(flora)

test_check("flora")
